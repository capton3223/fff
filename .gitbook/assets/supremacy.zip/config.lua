reach_min = 3.2
reach_max = 3.4
clicker_min = 4
clicker_max = 8
right_clicker_min = 15
right_clicker_max = 17
timer = 1.5